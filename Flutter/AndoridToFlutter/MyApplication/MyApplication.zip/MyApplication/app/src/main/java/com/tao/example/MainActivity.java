package com.tao.example;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;


import io.flutter.embedding.android.FlutterFragment;
import io.flutter.app.FlutterFragmentActivity;



public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrameLayout flutter_ui = findViewById(R.id.flutter_ui);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FlutterFragment flutterFragment = (FlutterFragment) fragmentManager.findFragmentByTag("flutter_fragment");
        if (flutterFragment == null) {
            flutterFragment = FlutterFragment.createDefault();
            fragmentManager
                    .beginTransaction()
                    .add(R.id.flutter_ui, flutterFragment, "flutter_fragment")
                    .commit();
        }


//        //设置默认位置
//        Intent intent = FlutterActivity.createDefaultIntent(this);

//        //选择性跳转某个路由界面
//        Intent intent = FlutterActivity.withNewEngine()
//                .initialRoute("")
//                .build(this);

//        //使用缓存的FlutterEngine(最大程度地减少启动标准的延迟)
//        FlutterEngine flutterEngine = new FlutterEngine(this);  //初始路由
//        //flutterEngine.getNavigationChannel().setInitialRoute("your/route/here"); //自定义路由
//        //开始执行Dart代码以预热FlutterEngine。
//        flutterEngine.getDartExecutor().executeDartEntrypoint(DartExecutor.DartEntrypoint.createDefault());
//        //缓存FlutterActivity要使用的FlutterEngine。
//        FlutterEngineCache.getInstance().put("my_engine_id", flutterEngine);
//        Intent intent = FlutterActivity
//                .withCachedEngine("my_engine_id")
//                .build(this);
//
//
//        findViewById(R.id.flutter_ui).setOnClickListener(v -> {
//            startActivity(intent);
//        });

    }
}
